'''
implement a function called sort_students that takes a list of students objects as input and sorts the
list bassed on their CGPA(cumulativ grade point average) in descending order. each student object
ha the fllowing attributes:name (string),roll_number (string), and cgpa(float). test the function
with different input lists of students.
'''

class Student:

  def__init__(self, name, roll_number, cgpa):
  self.name = Name
  self.roll_number = roll_number
  self.cgpa = cgpa


def sort_students(student_list):
 # sort the list of students in descending order of cgpa
  sorted_students = sorted(student_list,
                          key=lambda students: student.cgpa,
                           reverse=True)
  return sorted_students



# example usage:
students =[
  student("hari","A123",7.8),
  student("srikanth","A124",8.9),
  student("saumya","A125",9.1),
  student("mahindhar","A126",9.9),
]

sorted_students = sort_students(students)

# print the sorted list of students
for student in sorted_students:
  print("name: {},, roll_number: {},CGPA:{}".format(student.name,

students.roll_number,
                                                    student.cgpa))
  