"""
write a function called linear_search_product that takes the list of products and a target products 
name as input. the function should perform a linear search to find the target product in the list and
return a list of indices all occurences of the produts if found, or an empty list if_the products is not
found.
"""


def linearsearchproducts(productslist, targetproducts):
  indices = []

  for index, product in enumerate(productslist):
    if product == targetproducts:
      indices.append(index)

    return indices


# example usage:
products = ["shones","boot","loafer","shones","sandal","shones"]
taeget = "shones"
target = 'apple'
result = linearsearchproducts(products,target)
print(result)
